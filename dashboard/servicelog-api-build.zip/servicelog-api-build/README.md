# Service Log API

Serviço utilizado para gravar os logs dos testes realizados pelo AdvPR e TIR.

O pacote servicelog.api necessita do pacote do [Node.js](https://nodejs.org/) versão v12+.

## Configuração

Após a instalação procurar na raiz do projeto a pasta /src/config/configApp.js e realizar a configuração do serviço conforme os parâmetros abaixo.

- database - Tag database é responsavél pela comunicação do banco e possui os seguintes parâmetros:
  -- instanceName - Nome da Instância do banco de dados.
  -- host - Ip do servidor que está o banco de dados.
  -- username - Usuário do banco de dados.
  -- password - Senha do usuário do banco de dados.
  -- database - Nome do banco de dados criado para receber os registros.
- pathServer - Informado o caminho da pasta onde será enviado os arquivos json em caso do servidor não conseguir gravar o registro no banco de dados.
- appPort - Porta que será inicializado a aplicação.
- pathProcessed - Pasta de arquivos que já foram processados quando o servidor apresenta uma contigência.
- schedule - Nessa opção é configurado qual será frequência de verificação de arquivos jsons da pasta configurada no "pathServer".
  Ela possui uma sintaxe abaixa

#### Campos permitidos

```
 # ┌────────────── segundos (optional)
 # │ ┌──────────── minutos
 # │ │ ┌────────── horas
 # │ │ │ ┌──────── dias do mês
 # │ │ │ │ ┌────── mês
 # │ │ │ │ │ ┌──── dia da semana
 # │ │ │ │ │ │
 # │ │ │ │ │ │
 # * * * * * *
```

### Valores permitidos

| campos        | valores permitidos                              |
| ------------- | ----------------------------------------------- |
| segundos      | 0-59                                            |
| minutos       | 0-59                                            |
| hora          | 0-23                                            |
| dia do mês    | 1-31                                            |
| mês           | 1-12 (or names)                                 |
| dia da semana | 0-7 (nomes ou números, 0 ou 7 domingo à sábado) |

No padrão está da seguinte forma:

- \* 7,12,18,23 \* \* \* - Dessa forma será executado o serviço as 7hrs, 12hrs, 18hrs e 23hrs todos os dias.

## Instalação

Após a instalação procurar na raiz do projeto a pasta /scripts-bats e executar os scripts na sequência abaixo e em modo de administrador.

- install.bat - Descompactar os pacotes do npm.
- service-mode.bat - Instalação a api em modo de serviço.
- run.bat - Inicializa o serviço.

Em caso de necessidade poderá desligar o serviço com o bat abaixo.

- stop.bat - Desliga o serviço

## Estrutura json

##### Envio:

Exemplo de envio:

```
{
	"IDENTI"	: "RPO_D-1",
	"IDEXEC"	: "20190401",
	"TOOL"      : "ADVPR",
	"LASTEXEC"  : "20190930143040986",
	"TESTSUITE" : "MATR420TESTSUITE",
	"TESTCASE"  : "MATR420TESTCASE",
	"CTMETHOD"  : "MTR420_001",
	"CTNUMBER"  : "001",
	"TESTTYPE"  : "1",
	"EXECDATE"  : "20190930",
	"EXECTIME"  : "14:31:26",
	"PASS"      : "1",
	"FAIL"      : "0",
	"SECONDSCT" : "300",
	"FAILMSG"   : "",
	"COUNTRY"   : "BRA",
	"VERSION"   : "12",
	"RELEASE"   : "12.1.025",
	"PROGRAM"   : "MATR420",
	"PROGDATE"  : "20190101",
	"PROGTIME"  : "14:58:38",
	"USRNAME"   : "leonardo.quintania",
	"STATION"   : "SMART-TEST",
	"LIBVERSION": "20190916_151525",
	"APPVERSION": "7.00.170117A-20190517",
	"CLIVERSION": "17.3.0.8",
	"DBACCESS"  : "20181212",
	"DBTYPE"    : "MSSQL",
	"DBVERSION" : "2018",
	"SOTYPE"    : "Windows",
	"SOVERSION" : "Windows 10",
	"TOKEN"     : "ADVPR4541c86d1158400092A6c7089cd9e9ae-2019"
}
```

### Crie a imagem no docker

Basta executar o comando abaixo para realizar a construção de sua imagem.

```
docker build -t servicelog-api .
```

Após isso, se ainda não foi feita a construção da imagem da do front, poderá ser feita [aqui](https://code.engpro.totvs.com.br/engpro-automacao/servicelog-front).

Efetue a configuração conforme a necessidade no arquivo docker-compose.yml e após a configuração efetue o comando para iniciar os containers da API e da página

```
docker compose up
```
